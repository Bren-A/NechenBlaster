#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "StudentWorld.h"

class StudentWorld;
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class Actor : public GraphObject
{
public:
	Actor(int id, int x, int y, int depth = 0) : 
		m_dead(false), GraphObject(id, x, y, 0, 1, depth) 
	{
	
	}
	// Checks if it can interact with the player or not
	virtual bool touchable() = 0;
	virtual void doSomething() = 0;
	void dies(); // Changes to dead state
	bool isDead() const; // Returns whether the Actor is dead or not
	// Gets sprite ID to figure out what kind of object it is
	virtual int getID() const = 0; 
	virtual ~Actor();
private:
	bool m_dead;
};

class NachenBlaster : public Actor
{
public:
	NachenBlaster(StudentWorld* curr) : 
		m_world(curr), m_health(50), m_cabb(30), Actor(IID_NACHENBLASTER, 0, 128)
	{
	}
	void doSomething();
	bool touchable();
	int getID() const;
	~NachenBlaster();
private:
	StudentWorld* getWorld() const;
	StudentWorld* m_world;
	int m_health;
	int m_cabb;
};

// Enemies 
class Enemy : public Actor
{
public:

private:

};

class Smallgon : public Enemy
{
public:
	
private:

};
class Smoregon : public Enemy
{
public:

private:

};

class Snagglegon : public Enemy
{
public:

private:

};

// Projectiles
class Projectile : public Actor
{
public:

private:

};


// Items


// Passive
class Star : public Actor
{
public:
	Star(int x, int y) : Actor(IID_STAR, x, y, 3) // Depth of 3
	{
		// Random size between .05 and .5
		setSize(randInt(5, 50) / 100.0);
	}
	void doSomething();
	bool touchable();
	int getID() const;
	~Star();
private:

};

#endif // ACTOR_H_