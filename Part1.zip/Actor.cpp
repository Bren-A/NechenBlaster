#include "Actor.h"
#include "StudentWorld.h"

using namespace std;

// Actor functions
void Actor::dies()
{
	m_dead = true;
}

bool Actor::isDead() const
{
	return m_dead;
}

Actor::~Actor()
{
}

// NachenBlaster functions
StudentWorld* NachenBlaster::getWorld() const
{
	return m_world;
}

bool NachenBlaster::touchable()
{
	return true;
}

void NachenBlaster::doSomething()
{
	// Check to see if still alive, else return
	if (isDead())
		return;
	// Check to see button pressed
	int key;
	m_world->getKey(key);
		switch (key)
		{
		case KEY_PRESS_LEFT:
			if(getX() > 0)
				moveTo(getX() - 6, getY());
			break;
		case KEY_PRESS_RIGHT:
			if(getX() < VIEW_WIDTH - 1)
				moveTo(getX() + 6, getY());
			break;
		case KEY_PRESS_DOWN:
			if(getY() > 0)
				moveTo(getX(), getY() - 6);
			break;
		case KEY_PRESS_UP:
			if(getY() < VIEW_HEIGHT - 1)
				moveTo(getX(), getY() + 6);
			break;
		}

	// If space bar && has 5 energy points, fire cabbagge
		// Add new cabbage object && fire

	// If tab pressed 
	if (key == KEY_PRESS_SPACE)
		dies();
}

int NachenBlaster::getID() const
{
	return IID_NACHENBLASTER;
}
NachenBlaster::~NachenBlaster()
{
}
// Star functions
void Star::doSomething()
{
	if (getX() < 0)
		dies();
	moveTo(getX() - 1, getY());
}

bool Star::touchable()
{
	return false;
}

int Star::getID() const
{
	return IID_STAR;
}
Star::~Star()
{
}