#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include <string>

// Added classes
#include <list>
#include "Actor.h"

// New constants
const int MAX_STARS_ON_SCREEN = 30; // Makes sure there aren't too many stars on screen

class Actor;
// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetDir);
    virtual int init();
    virtual int move();
    virtual void cleanUp();
	~StudentWorld();
private:
	// Sets stars for the beginning of the game
	void setStars();
	// Creates a set number of stars and plots them randomly between two given x values
	void setStarsRange(int nStars, int r1, int r2);

	std::list<Actor*> m_objects;
	// Keeps track of the number of stars on screen
	int m_nStars;
};

#endif // STUDENTWORLD_H_
