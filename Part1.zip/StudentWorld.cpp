#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>

// My additions
#include <list>
#include "Actor.h"

using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetDir)
: m_nStars(0), GameWorld(assetDir)
{
	
}

int StudentWorld::init()
{
	m_objects.push_back(new NachenBlaster(this));
	setStars();
	return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
	for (list<Actor*>::iterator i = m_objects.begin(); m_objects.end() != m_objects.begin() && i != m_objects.end(); i++)
	{
		(*i)->doSomething();
		if ((*i)->isDead())
		{
			// Set new iterator to object currently needed to delete
			list<Actor*>::iterator temp = i;

			// Check if it's at the beginning of the list
			if (i == m_objects.begin())
			{
				i++; i++; // Move forward instead of back 
			}
			
			i--;

			// Decrement starcount if dead one was star
			if((*temp)->getID() == IID_STAR)
				m_nStars--;

			// Delete object at iterator
			delete *temp;

			// Remove iterator
			m_objects.erase(temp);
			
			// Add more stars if they have gone off screen and have been deleted
			if (m_nStars <= MAX_STARS_ON_SCREEN)
				m_objects.push_back(new Star(VIEW_WIDTH - 1, randInt(0, VIEW_HEIGHT - 1)));
		}
	}
	return GWSTATUS_CONTINUE_GAME;    
}

void StudentWorld::cleanUp()
{
	list<Actor*>::iterator i = m_objects.begin();
	while (m_objects.end() != m_objects.begin() && i != m_objects.end())
	{
		delete *i;
		m_objects.erase(i);
		i = m_objects.begin();
	}
}

void StudentWorld::setStars()
{
		setStarsRange(30, 0, VIEW_WIDTH - 1);
}

void StudentWorld::setStarsRange(int n, int r1, int r2)
{
	for (int i = 0; i < n; i++)
	{
		m_objects.push_back(new Star(randInt(r1, r2), randInt(0, VIEW_HEIGHT - 1)));
		m_nStars++;
	}
}

StudentWorld::~StudentWorld()
{
	cleanUp();
}
